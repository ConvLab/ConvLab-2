We made the following changes to the original train logs. Each of the individual changes can be found in Fix Log.txt

============
Comma Issues
============
In the original file, single addresses with commas were split into multiple objects in the labelling.

For example:

	"8 mercers row, mercers row industrial estate"

Is labelled as:
            [
              "Addr",
              "8 Mercers Row"
            ],
            [
              "Addr",
              "Mercers Row Industrial Estate"
            ]

These have been merged into single address labels

==============
Exact Matching
==============
Each user utterance was processed to look for entity matches using the "LabelMatch.json" file to capture missing labels
and fix mis-labelled entities for "stay", "people" and "stars" entities.

For example:
PMUL3296: (Hotel-stay: 4 [WAS: 2]) = Yeah , could you book me a room for 2 people for 4 nights starting Tuesday ?
PMUL3296: (Hotel-people: 2 [WAS: 4]) = Yeah , could you book me a room for 2 people for 4 nights starting Tuesday ?
 MUL1618: (Restaurant-people: 7) = Pizza Hut City Centre sounds fine .   Could you book a table for 7 people there for me ?

==================
Fix Missing Spans
==================
For each user utterance we looked at the dialog acts for the user utterance, the following agent utterance dialog acts as well as the metadata
for potential missing labels.  We then looked for a matching label in the user utterance, creating new spans when a
match was found

For example:
 MUL2635: (Hotel-parking-yes         ) = I 'm looking for a place in the cheap price range with free parking .
 MUL2635: (Hotel-internet-yes        ) = Does it also have free wifi ?
 MUL2635: (Hotel-name-allenbell      ) = I want to go from the Allenbell to the Cafe Jello Gallery . I want to leave the museum by 23:00 .

======================
Fix Inconsistent Spans
======================
We looked for identical user utterances that were labelled inconsistently in different dialogs, and where possible made them consistent.

For example:
"I 'll be leaving from peterborough and would like to leave after 09:00 ."

PMUL4183:[["Train-Inform","Depart","peterborough",5,5]]                                          
PMUL1822:[["Train-Inform","Depart","peterborough",5,5],["Train-Inform","Leave","09:00",12,12]]  

  